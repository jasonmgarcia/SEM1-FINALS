package com.phonegap.plugins.pushnotifications.gcm;

public enum VibrateType
{
    NO_VIBRATE, DEFAULT_MODE, ALWAYS
}
