package com.phonegap.plugins.pushnotifications.gcm;

public enum SoundType
{
    NO_SOUND, DEFAULT_MODE, ALWAYS
}
